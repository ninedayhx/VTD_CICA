#include "ros/ros.h"
#include <yaml-cpp/yaml.h>
#include "std_msgs/Header.h"
#include "std_msgs/Header.h"
#include "common_msgs/Control_Test.h"
#include "RDBHandler.hh"

#include <iostream>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <functional>
#include <sstream>
#include <jsoncpp/json/json.h>
#include <cmath>
#include <thread>
#include <signal.h>
#include "scpIcd.h"
#include <sys/ioctl.h>

#define VERSION "20221130"
#define VTD_IP "127.0.0.1"
#define VTD_RDB_PORT 48190
#define VTD_ODR_PORT 48220
#define CARSIM_IP "127.0.0.1"
#define CARSIM_PORT 8888
#define DEFAULT_BUFFER 204800
#define VEHICLE_ID 1
#define MAX_CONNECTIONS 3
#define SCP_PORT 48179
#define DEFAULT_PORT_TC 48190 /* for image port it should be 48192 */
#define DEFAULT_PORT_SENSOR 62001
#define FIONBIO 0x5421

#define ROS_RATE 50
#define TOPIC_VEHICLE_CONTROL "/control_test"
#define TOPIC_VEHICLE_TRAJECTORY "/cicv_amr_trajectory"

using std::cerr;
using std::cout;
using std::endl;
using std::ostringstream;
using std::string;
using std::thread;
using std::to_string;
using std::vector;

double x_offset;
double y_offset;
double xBase;
double yBase;

template <typename T>

/**
 * @description: 设置yaml
 * @return {*}
 * @author: Sun Yalun
 */
void operator>>(const YAML::Node &node, T &config)
{
    config = node.as<T>();
}

// type definition for connection handling
typedef struct
{
    int id;                     // unique connection ID
    char serverAddr[128];       // Server to connect to
    int port;                   // Port on server to connect to
    int desc;                   // client (socket) descriptor
    unsigned int bytesInBuffer; // used size of receive buffer
    size_t bufferSize;          // total size of receive buffer;
    unsigned char *pData;       // pointer to receive buffer
} Connection_t;

// connection instances
Connection_t sConnection[MAX_CONNECTIONS];

// globally store nearest object
RDB_OBJECT_STATE_t mNearestObject;
RDB_OBJECT_STATE_t mOwnObject;

struct Control
{
    double throttle;
    double steering;
    double brake;
    int gear;
};

struct Coord
{
    double x;
    double y;
    double z;
    double h;
    double p;
    double r;
};

struct VehicleData
{
    Control control;
    Coord refPos; // real axle center
    Coord speed;
    Coord accel;
    Coord wheelPos[4]; // LF, LR, RR, RF
};

struct TrajectoryPoint_xyz
{
    double x;
    double y;
    double z;
};

// 函数声明
void drawLines(std::vector<TrajectoryPoint_xyz> &points);
void sendSCPMessage(int sClient, const char *text, bool verbose);
void initConnection(Connection_t &conn);
int openPort(int &descriptor, int portNo, const char *serverAddr);
int scpCount = 0;
float total = 0;
int tcpCount = 0;
int totalPerTcp = 0;

int connectTCP(const string &, int, const string &);

VehicleData vehicleData{};
bool enableCarsim = false;
int carsimSocketFD;
int vtdOdrSocketFD;
int vtdRdbSocketFD;
int vtd_TC_SocketFD;
int vtd_Sensor_SocketFD;
int vtd_SCP_SocketFD;
string vtdIP;
double simTime;
unsigned int frameNo;
bool SCPCanSend = true;
int last_frameNo = -1;
int light_type = 3;

/**
 * @brief send
 *
 * @param vtdRdbSocketFD
 * @return int
 */
int sendRdbMsg(int vtdRdbSocketFD)
{

    Framework::RDBHandler myHandler;
    myHandler.initMsg();
    myHandler.addPackage(0, 0, RDB_PKG_ID_START_OF_FRAME);

    if (enableCarsim)
    {
        auto objectState = (RDB_OBJECT_STATE_t *)myHandler.addPackage(0, 0, RDB_PKG_ID_OBJECT_STATE, 1, true);
        if (!objectState)
        {
            fprintf(stderr, "sendRdbObjectState: could not create objectState\n");
            return -1;
        }

        objectState->base.id = 1;
        objectState->base.category = RDB_OBJECT_CATEGORY_PLAYER;
        objectState->base.type = RDB_OBJECT_TYPE_PLAYER_CAR;

        objectState->base.pos.x = vehicleData.refPos.x;
        objectState->base.pos.y = vehicleData.refPos.y;
        objectState->base.pos.z = vehicleData.refPos.z;
        objectState->base.pos.h = vehicleData.refPos.h;
        objectState->base.pos.p = vehicleData.refPos.p;
        objectState->base.pos.r = vehicleData.refPos.r;
        objectState->ext.speed.x = vehicleData.speed.x;
        objectState->ext.speed.y = vehicleData.speed.y;
        objectState->ext.accel.x = vehicleData.accel.x;
        objectState->ext.accel.y = vehicleData.accel.y;
    }

    auto *drvCtlState = (RDB_DRIVER_CTRL_t *)myHandler.addPackage(0, 0, RDB_PKG_ID_DRIVER_CTRL, 1);
    if (!drvCtlState)
    {
        fprintf(stderr, "sendRdbDriverCtrl: could not create driverCtl\n");
        return -1;
    }
    drvCtlState->playerId = VEHICLE_ID;
    drvCtlState->validityFlags = RDB_DRIVER_INPUT_VALIDITY_ADD_ON |
                                 RDB_DRIVER_INPUT_VALIDITY_STEERING_WHEEL |
                                 RDB_DRIVER_INPUT_VALIDITY_THROTTLE |
                                 RDB_DRIVER_INPUT_VALIDITY_GEAR |
                                 RDB_DRIVER_INPUT_VALIDITY_BRAKE |
                                 RDB_DRIVER_INPUT_VALIDITY_FLAGS;
    drvCtlState->steeringWheel = vehicleData.control.steering;
    drvCtlState->throttlePedal = vehicleData.control.throttle;
    drvCtlState->gear = vehicleData.control.gear;
    drvCtlState->brakePedal = vehicleData.control.brake;

    // 根据规划的路线的light_type设置转向灯
    if (light_type == 1)
    {
        drvCtlState->flags = RDB_DRIVER_FLAG_INDICATOR_R;
    }
    else if (light_type == 2)
    {
        drvCtlState->flags = RDB_DRIVER_FLAG_INDICATOR_L;
    }
    else if (light_type == 4)
    {
        drvCtlState->flags = RDB_DRIVER_FLAG_INDICATOR_R | RDB_DRIVER_FLAG_INDICATOR_L;
    }
    else
    {
        drvCtlState->flags = RDB_DRIVER_FLAG_NONE;
    }

    myHandler.addPackage(0, 0, RDB_PKG_ID_END_OF_FRAME);

    int ret = send(vtdRdbSocketFD, (const char *)(myHandler.getMsg()), myHandler.getMsgTotalSize(), 0);
    if (ret == 0)
        fprintf(stdout, "VTD Socket closed\n");
    if (ret < 0)
        fprintf(stderr, "sendRdbMsg: could not send RDB msg\n");
    if (ret <= 0)
    {
        fprintf(stderr, "\nRDB disconnected, reconnecting...\n\n");
        close(vtdRdbSocketFD);
        vtdRdbSocketFD = connectTCP(vtdIP, VTD_RDB_PORT, "VtdRdbPort");
        ret = send(vtdRdbSocketFD, (const char *)(myHandler.getMsg()), myHandler.getMsgTotalSize(), 0);
    }

    return ret;
}

/**
 * @brief send control message to Carsim
 *
 * @param sendSocketFD
 * @param data
 */
void sendCarsimData(int sendSocketFD)
{

    string sendData;
    ostringstream oss;

    oss << "{";

    oss << R"("action":1,)";

    oss << R"("control":{)";
    oss << R"("throttle":)" << vehicleData.control.throttle << ",";
    oss << R"("steering":)" << vehicleData.control.steering << ",";
    oss << R"("brake":)" << vehicleData.control.brake << ",";
    oss << R"("gear":)" << vehicleData.control.gear << "},";

    oss << R"("ground_z":{)";
    oss << R"("ground_z_l1":)" << vehicleData.wheelPos[0].z << ",";
    oss << R"("ground_z_l2":)" << vehicleData.wheelPos[1].z << ",";
    oss << R"("ground_z_r1":)" << vehicleData.wheelPos[3].z << ",";
    oss << R"("ground_z_r2":)" << vehicleData.wheelPos[2].z << "}";

    oss << "}";
    oss << "\n";
    sendData = oss.str();

    auto len = sendData.length();
    char charData[len + 1];
    strcpy(charData, sendData.c_str());

    int ret = send(sendSocketFD, (const char *)charData, len, 0); // did not send the c_string terminator
    if (ret <= 0)
    {
        fprintf(stderr, "Error: failed to send Carsim data\n");
        exit(0);
    }
    cerr << "send msg to CarSIM" << endl;
    // fprintf(stdout, "\nsend %d bytes to Carsim\n", ret);
}

/**
 * @brief
 *
 * @param vtdOdrSocketFD
 * @return int
 */
int sendRdbRoadQuery(int vtdOdrSocketFD)
{

    Framework::RDBHandler myHandler;
    myHandler.initMsg();
    myHandler.addPackage(0, 0, RDB_PKG_ID_START_OF_FRAME, 0);
    auto *roadQuery = (RDB_ROAD_QUERY_t *)myHandler.addPackage(0, 0, RDB_PKG_ID_ROAD_QUERY, 4);
    if (!roadQuery)
    {
        fprintf(stderr, "sendRoadQuery: could not create roadQuery\n");
        return -1;
    }
    myHandler.addPackage(0, 0, RDB_PKG_ID_END_OF_FRAME, 0);

    roadQuery[0].id = 0;
    roadQuery[0].x = vehicleData.wheelPos[0].x;
    roadQuery[0].y = vehicleData.wheelPos[0].y;
    roadQuery[0].flags = RDB_ROAD_QUERY_FLAG_NONE;

    roadQuery[1].id = 1;
    roadQuery[1].x = vehicleData.wheelPos[1].x;
    roadQuery[1].y = vehicleData.wheelPos[1].y;
    roadQuery[1].flags = RDB_ROAD_QUERY_FLAG_NONE;

    roadQuery[2].id = 2;
    roadQuery[2].x = vehicleData.wheelPos[2].x;
    roadQuery[2].y = vehicleData.wheelPos[2].y;
    roadQuery[2].flags = RDB_ROAD_QUERY_FLAG_NONE;

    roadQuery[3].id = 3;
    roadQuery[3].x = vehicleData.wheelPos[3].x;
    roadQuery[3].y = vehicleData.wheelPos[3].y;
    roadQuery[3].flags = RDB_ROAD_QUERY_FLAG_NONE;

    int ret = send(vtdOdrSocketFD, (const char *)(myHandler.getMsg()), myHandler.getMsgTotalSize(), 0);
    if (ret == 0)
        fprintf(stdout, "VTD Socket closed\n");
    if (ret < 0)
        fprintf(stderr, "sendRoadQuery: could not send roadQuery\n");
    return ret;
}

/**
 * @brief keep receiving messave from Carsim
 *
 * @param carsimSocketFD
 * @return string
 */
void recvCarsimData(int carsimSocketFD)
{

    auto defaultSize = 2048;
    char szBuffer[defaultSize];

    int ret = recv(carsimSocketFD, &szBuffer, sizeof(szBuffer), 0);
    if (ret <= 0)
    {
        fprintf(stderr, "Error: failed to receive Carsim data\n");
        exit(0);
    }
    // fprintf(stdout, "recv %d bytes from Carsim\n", ret);

    string recvData(szBuffer);
    string carsimData = recvData.substr(0, ret - 1); // remove "\n" at the end of the incoming string msg
    cout << "Carsim Data Received:" << endl
         << carsimData << endl;

    Json::Reader reader;
    Json::Value root;
    if (reader.parse(carsimData, root))
    {
        // parse ref data
        vehicleData.refPos.x = root["posture"]["x"].asDouble();
        vehicleData.refPos.y = root["posture"]["y"].asDouble();
        vehicleData.refPos.z = root["posture"]["z"].asDouble();
        vehicleData.refPos.h = root["posture"]["yaw"].asDouble();
        vehicleData.refPos.p = root["posture"]["pitch"].asDouble();
        vehicleData.refPos.r = root["posture"]["roll"].asDouble();
        // parse speed/accel data
        vehicleData.speed.x = root["speed"]["v_ground_x"].asDouble();
        vehicleData.speed.y = root["speed"]["v_ground_y"].asDouble();
        vehicleData.accel.x = root["speed"]["accel_x"].asDouble(); // TODO: transfer coord-sys to ground
        vehicleData.accel.y = root["speed"]["accel_x"].asDouble(); // TODO: transfer coord-sys to ground
        // parse wheels data
        vehicleData.wheelPos[0].x = root["contact_point"]["contact_point_l1"]["coord_x"].asDouble();
        vehicleData.wheelPos[0].y = root["contact_point"]["contact_point_l1"]["coord_y"].asDouble();
        vehicleData.wheelPos[1].x = root["contact_point"]["contact_point_l2"]["coord_x"].asDouble();
        vehicleData.wheelPos[1].y = root["contact_point"]["contact_point_l2"]["coord_y"].asDouble();
        vehicleData.wheelPos[2].x = root["contact_point"]["contact_point_r2"]["coord_x"].asDouble();
        vehicleData.wheelPos[2].y = root["contact_point"]["contact_point_r2"]["coord_y"].asDouble();
        vehicleData.wheelPos[3].x = root["contact_point"]["contact_point_r1"]["coord_x"].asDouble();
        vehicleData.wheelPos[3].y = root["contact_point"]["contact_point_r1"]["coord_y"].asDouble();
        cout << "Carsim Data Parsed" << endl;
    }
    else
    {
        cerr << "Error: failed to parse Carsim Json-format data" << endl;
    }
}

/**
 * @brief copy ROS message Control_Test from ROS topic TOPIC_VEHICLE_CONTROL to local storage
 *
 * @param msg
 */
void controlCallback(const common_msgs::Control_Test &msg)
{
    cerr << "\n\n"
         << endl;
    ROS_INFO("v%s, Topics Received, %d, %f", VERSION, frameNo, simTime);
    cerr << "[frameNo, simFrame]: [" << frameNo << ", " << simTime << "]" << endl;

    vehicleData.control.throttle = msg.ThrottlePedal;
    vehicleData.control.steering = msg.SteeringAngle / 180 * M_PI;
    vehicleData.control.brake = msg.BrakePedal;
    vehicleData.control.gear = msg.Gear;

    if (enableCarsim)
    {

        /*******************************
         * Send RDB_ROAD_QUERY_t to VTD *
         *******************************/
        int ret1 = sendRdbRoadQuery(vtdOdrSocketFD);
        if (ret1 <= 0)
        {
            fprintf(stderr, "\nVTD disconnected, reconnecting...\n\n");
            close(vtdOdrSocketFD);
            vtdOdrSocketFD = connectTCP(vtdIP, VTD_ODR_PORT, "VtdOdrPort");
        }
        cerr << "RoadQuery Sent" << endl;
    }
    else
    {
        sendRdbMsg(vtdRdbSocketFD);
        cerr << "RDB Msg Sent" << endl;
    }
}

void drawLines(std::vector<TrajectoryPoint_xyz> &points)
{
    std::stringstream sstrSCP;

    for (int i = 0; i < points.size() - 1; i++)
    {
        sstrSCP << "<Symbol name=\"trajectoryLine" << i << "\" duration=\"0.2\" > ";
        sstrSCP << "<Line fromX=\"" << points[i].x - points[0].x
                << "\" fromY=\"" << points[i].y - points[0].y
                << "\" fromZ=\"" << points[i].z - points[0].z + 0.2
                << "\" toX=\"" << points[i + 1].x - points[0].x
                << "\" toY=\"" << points[i + 1].y - points[0].y
                << "\" toZ=\"" << points[i + 1].z - points[0].z + 0.2;
        if (i % 2 == 0)
            // sstrSCP << "\" colorRGB=\"0xff0000\" width=\"4\" first=\"true\" /> " ;
            sstrSCP << "\" colorRGB=\"0x33a3dc\" width=\"4\" first=\"true\" /> ";
        else
            // sstrSCP << "\" colorRGB=\"0x0000ff\" width=\"4\" first=\"true\" /> " ;
            sstrSCP << "\" colorRGB=\"0x7bbfea\" width=\"4\" first=\"true\" /> ";

        sstrSCP << "<PosInertial x=\"" << points[0].x << "\" y=\"" << points[0].y << "\" z=\"" << points[0].z
                << "\" /> <Orientation type=\"inertial\" /> </Symbol>";
    }
    // const char* SCP_test = "<Query entity=\"taskControl\"><SimState /></Query>";
    // sendSCPMessage( sConnection[2].desc, sstrSCP.str().c_str() , false);
    std::cout << "vtd_SCP_SocketFD: " << vtd_SCP_SocketFD << std::endl;
    sendSCPMessage(vtd_SCP_SocketFD, sstrSCP.str().c_str(), false);
    // sendSCPMessage( vtd_SCP_SocketFD, SCP_test , false);
}

void sendSCPMessage(int sClient, const char *text, bool verbose)
{
    if (!text)
        return;

    if (!strlen(text))
        return;

    size_t totalSize = sizeof(SCP_MSG_HDR_t) + strlen(text);
    SCP_MSG_HDR_t *msg = (SCP_MSG_HDR_t *)new char[totalSize];

    // target pointer for actual SCP message data
    char *pData = (char *)msg;
    pData += sizeof(SCP_MSG_HDR_t);

    // fill the header information
    msg->magicNo = SCP_MAGIC_NO;
    msg->version = SCP_VERSION;
    msg->dataSize = strlen(text);
    sprintf(msg->sender, "Planned track");
    sprintf(msg->receiver, "any");

    // fill the actual data section (no trailing \0 required)

    memcpy(pData, text, strlen(text));

    int retVal = ::send(sClient, msg, totalSize, 0);

    total += totalSize;
    totalPerTcp += totalSize;
    cout << "totalSize: " << totalSize << endl;
    fprintf(stderr, "send SCP cmd %d with TCP %d for %d bytes - total %.0f bytes, totalPerTcp: %d\n", scpCount++, tcpCount, totalSize, total, totalPerTcp);

    if (!retVal)
        fprintf(stderr, "sendSCPMessage: could not send message.\n");

    if (verbose)
        fprintf(stderr, "\nsendSCPMessage: sent %d characters in a message of %d bytes: ***%s***\n",
                msg->dataSize, totalSize, text);

    usleep(45000);
    // Manual release memory
    if (totalPerTcp > 10240000)
    {
        // fprintf( stderr, "zhangyu: close SCP socket\n");
        close(vtd_SCP_SocketFD);
        // fprintf( stderr, "zhangyu: open SCP socket\n");
        vtd_SCP_SocketFD = connectTCP(VTD_IP, sConnection[2].port, sConnection[2].serverAddr);
        tcpCount++;
        totalPerTcp = 0;
        total = 0;
    }

    // free allocated buffer space
    delete msg;
}

/**
 * @brief store Ego coord-z info
 *
 * @param simTime
 * @param simFrame
 * @param item
 */
void handleRDBitem(const double &simTime, const unsigned int &simFrame, RDB_CONTACT_POINT_t &item)
{
    auto wheelID = item.id;
    vehicleData.wheelPos[wheelID].z = item.roadDataIn.z;
    fprintf(stdout, "ContactPoint Received: id = %d, z = %f\n", wheelID, item.roadDataIn.z);

    // since 4 wheels info are received consecutively, only send carsim data once
    // use any arbitrary wheelID to trigger the sending action
    if (3 == wheelID)
    {

        /***************************
         * Send Json-Data to Carsim *
         ***************************/
        sendCarsimData(carsimSocketFD);
        cerr << "Carsim Data Sent" << endl;

        /**********************************
         * Receive CarSIM Json-Format Data *
         **********************************/
        recvCarsimData(carsimSocketFD);

        sendRdbMsg(vtdRdbSocketFD);
        cerr << "RDB Msg Sent" << endl;
    }
}

/**
 * @brief
 *
 * @param simTime
 * @param simFrame
 * @param entryHdr
 */
void parseRDBMessageEntry(const double &simTime, const unsigned int &simFrame, RDB_MSG_ENTRY_HDR_t *entryHdr)
{
    if (!entryHdr)
        return;

    int noElements = entryHdr->elementSize ? (entryHdr->dataSize / entryHdr->elementSize) : 0;

    if (!noElements)
    { // some elements require special treatment
        switch (entryHdr->pkgId)
        {

        case RDB_PKG_ID_START_OF_FRAME:
            // fprintf( stderr, "void parseRDBMessageEntry: got start of frame\n" );
            break;

        case RDB_PKG_ID_END_OF_FRAME:
            // fprintf( stderr, "void parseRDBMessageEntry: got end of frame\n" );
            break;

        default:
            return;
        }
        return;
    }

    char *dataPtr = (char *)entryHdr;
    dataPtr += entryHdr->headerSize;

    while (noElements--)
    {
        switch (entryHdr->pkgId)
        {

        case RDB_PKG_ID_CONTACT_POINT:
            handleRDBitem(simTime, simFrame, *((RDB_CONTACT_POINT_t *)dataPtr));
            break;

        default:
            break;
        }
        dataPtr += entryHdr->elementSize;
    }
}

/**
 * @brief
 *
 * @param msg
 * @param isImage
 */
void parseRDBMessage(RDB_MSG_t *msg, bool &isImage)
{
    if (!msg)
        return;

    if (!msg->hdr.dataSize)
        return;

    auto *entry = (RDB_MSG_ENTRY_HDR_t *)(((char *)msg) + msg->hdr.headerSize);
    uint32_t remainingBytes = msg->hdr.dataSize;

    while (remainingBytes)
    {
        parseRDBMessageEntry(msg->hdr.simTime, msg->hdr.frameNo, entry);

        isImage |= (entry->pkgId == RDB_PKG_ID_IMAGE);

        remainingBytes -= (entry->headerSize + entry->dataSize);

        if (remainingBytes)
            entry = (RDB_MSG_ENTRY_HDR_t *)((((char *)entry) + entry->headerSize + entry->dataSize));
    }
}

/**
 * @brief keep receiving messave from VTD
 *
 * @param vtdRdbSocketFD
 */
void recvVtdData(int vtdInterfaceSocketFD, string targetIP, int targetPort)
{

    char szBuffer[DEFAULT_BUFFER];
    while (true)
    {

        /// receive raw data from vtd
        int ret;
        unsigned int bytesInBuffer = 0;
        size_t bufferSize = sizeof(RDB_MSG_HDR_t);
        auto *pData = (unsigned char *)calloc(1, bufferSize);

        for (;;)
        {
            cout << simTime << endl;
            cout << "targetPort: " << targetPort << endl;

            // if (48179 == targetPort && simTime>3){
            //     const char* SCP_test = "<Query entity=\"taskControl\"><SimState /></Query>";
            //     sendSCPMessage( vtd_SCP_SocketFD, SCP_test , true);
            //     cout<<"000000000000"<<endl;
            // }
            bool bMsgComplete = false;

            // read a complete message
            while (!bMsgComplete)
            {
                // if (48179 == targetPort) cout<<"1111111"<<endl;
                ret = recv(vtdInterfaceSocketFD, &szBuffer, DEFAULT_BUFFER, 0);
                // if (48179 == targetPort) cout<<"2222222"<<endl;
                if (ret <= 0)
                {
                    // ret_static = 0;
                    auto strPort = to_string(targetPort).c_str();
                    fprintf(stderr, "\n%s disconnected, reconnecting...\n\n", strPort);
                    close(vtdInterfaceSocketFD);
                    vtdInterfaceSocketFD = connectTCP(targetIP, targetPort, strPort);
                    // if (48190 == targetPort) vtdRdbSocketFD = vtdInterfaceSocketFD;
                    if (48179 == targetPort)
                        vtd_SCP_SocketFD = vtdInterfaceSocketFD;
                    break;
                }

                // do we have to grow the buffer??
                if ((bytesInBuffer + ret) > bufferSize)
                {
                    pData = (unsigned char *)realloc(pData, bytesInBuffer + ret);
                    bufferSize = bytesInBuffer + ret;
                }

                memcpy(pData + bytesInBuffer, &szBuffer, ret);
                bytesInBuffer += ret;

                // already complete messagae?
                if (bytesInBuffer >= sizeof(RDB_MSG_HDR_t))
                {
                    auto *hdr = (RDB_MSG_HDR_t *)pData;

                    // is this message containing the valid magic number?
                    if (hdr->magicNo != RDB_MAGIC_NO)
                    {
                        // printf( "message receiving is out of sync; discarding data" );
                        bytesInBuffer = 0;
                    }

                    while (bytesInBuffer >= (hdr->headerSize + hdr->dataSize))
                    {
                        unsigned int msgSize = hdr->headerSize + hdr->dataSize;
                        bool isImage = false;

                        // now parse the message
                        parseRDBMessage((RDB_MSG_t *)pData, isImage);

                        // remove message from queue
                        memmove(pData, pData + msgSize, bytesInBuffer - msgSize);
                        bytesInBuffer -= msgSize;

                        bMsgComplete = true;
                        if (VTD_RDB_PORT == targetPort)
                        {
                            simTime = hdr->simTime;
                            frameNo = hdr->frameNo;
                        }
                    }
                }
            }
        }
    }
}

/**
 * @brief make a TCP connection
 *
 * @param targetIP is the target ip
 * @param targetPort is the target port
 * @return the socketFD
 */
int connectTCP(const string &targetIP, int targetPort, const string &targetName)
{

    struct sockaddr_in server
    {
    };
    struct hostent *host;
    int sClient;
    char szServer[128];

    strcpy(szServer, targetIP.c_str());

    sClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); // 创建套件字

    if (sClient == -1)
    {
        fprintf(stderr, "socket() failed: %s\n", strerror(errno));
        // return 1;
    }

    int opt = 1;
    setsockopt(sClient, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));

    server.sin_family = AF_INET;                  // 使用IPv4地址
    server.sin_port = htons(targetPort);          // 具体的端口号
    server.sin_addr.s_addr = inet_addr(szServer); // 具体的ip地址

    /// If the supplied server address wasn't in the form
    /// "aaa.bbb.ccc.ddd" it's a hostname, so try to resolve it

    if (server.sin_addr.s_addr == INADDR_NONE)
    {
        host = gethostbyname(szServer);
        if (nullptr == host)
        {
            fprintf(stderr, "Unable to resolve %s server: %s\n", szServer, targetName.c_str());
            return 1;
        }
        memcpy(&server.sin_addr, host->h_addr_list[0], host->h_length);
    }

    /// wait for connection
    bool bConnected = false;
    while (ros::ok() && !bConnected)
    {
        if (connect(sClient, (struct sockaddr *)&server, sizeof(server)) == -1)
        {
            if (targetName != "48190")
                fprintf(stderr, "%s connect() failed_1: %s\n", strerror(errno), targetName.c_str());

            std::cout << "simTime: " << simTime << std::endl;
            sleep(1);
        }
        else
        {
            bConnected = true;
        }
    }
    // std::cout<<"simTime: "<<simTime<<std::endl;

    cout << targetName << " connected!"
         << " | IP = " << targetIP << " | port = " << targetPort << endl;
    return sClient;
}

/**
 * @brief gracefully exit the program, elegance never goes out of fashion.
 *
 * @param sig
 */
void ExitGracefully(int sig)
{
    cerr << "!!! Received SIGSEGV Signal: " << signal << endl;
    ros::shutdown();
    exit(sig);
}

void initConnections()
{
    memset(sConnection, 0, MAX_CONNECTIONS * sizeof(Connection_t));

    // general initialization
    for (int i = 0; i < MAX_CONNECTIONS; i++)
    {
        initConnection(sConnection[i]);
        sConnection[i].id = i;
    }

    // additional individual initalization``
    sConnection[0].port = DEFAULT_PORT_TC;
    sConnection[1].port = DEFAULT_PORT_SENSOR;
    sConnection[2].port = SCP_PORT;

    // additional individual initalization``
    strcpy(sConnection[0].serverAddr, "TcRdbPort");
    strcpy(sConnection[1].serverAddr, "SensorPort");
    strcpy(sConnection[2].serverAddr, "TcScpPort");
}

void initConnection(Connection_t &conn)
{
    strcpy(conn.serverAddr, "127.0.0.1");

    conn.desc = -1;
    conn.bufferSize = sizeof(RDB_MSG_t);
    conn.pData = (unsigned char *)calloc(1, conn.bufferSize);
}

int openPort(int &descriptor, int portNo, const char *serverAddr)
{
    struct sockaddr_in server;
    struct hostent *host = NULL;

    //
    // Create the socket, and attempt to connect to the server
    //
    descriptor = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (descriptor == -1)
    {
        fprintf(stderr, "openPort: socket() failed: %s\n", strerror(errno));
        return 0;
    }

    int opt = 1;
    setsockopt(descriptor, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));

    server.sin_family = AF_INET;
    server.sin_port = htons(portNo);
    server.sin_addr.s_addr = inet_addr(serverAddr);

    //
    // If the supplied server address wasn't in the form
    // "aaa.bbb.ccc.ddd" it's a hostname, so try to resolve it
    //
    if (server.sin_addr.s_addr == INADDR_NONE)
    {
        host = gethostbyname(serverAddr);

        if (host == NULL)
        {
            fprintf(stderr, "openPort: unable to resolve server: %s\n", serverAddr);
            return 0;
        }
        memcpy(&server.sin_addr, host->h_addr_list[0], host->h_length);
    }

    //   set to non blocking
    // opt = 1;
    // ioctl( descriptor, FIONBIO, &opt );

    // wait for connection
    bool bConnected = false;

    while (!bConnected)
    {
        if (connect(descriptor, (struct sockaddr *)&server, sizeof(server)) == -1)
        {
            fprintf(stderr, "connect() failed: %s\n", strerror(errno));
            sleep(1);
        }
        else
            bConnected = true;
    }

    fprintf(stderr, "port % d connected!\n", portNo);

    return 1;
}

void usage()
{
    printf("usage: client [-t:x] [-s:IP]\n\n");
    printf("       -t:x      taskControl port\n");
    printf("       -s:x      sensor port\n");
    printf("       -T:IP     taskControl IPv4 address\n");
    printf("       -S:IP     sensor IPv4 address\n");
    exit(1);
}

void ValidateArgs(int argc, char **argv)
{
    for (int i = 1; i < argc; i++)
    {
        if ((argv[i][0] == '-') || (argv[i][0] == '/'))
        {
            switch (argv[i][1])
            {
            case 't': // Remote port taskControl
                if (strlen(argv[i]) > 3)
                    sConnection[0].port = atoi(&argv[i][3]);
                break;
            case 's': // Remote port sensor
                if (strlen(argv[i]) > 3)
                    sConnection[1].port = atoi(&argv[i][3]);
                break;
            case 'T': // TC server
                if (strlen(argv[i]) > 3)
                    strcpy(sConnection[0].serverAddr, &argv[i][3]);
                break;
            case 'S': // sensor server
                if (strlen(argv[i]) > 3)
                    strcpy(sConnection[1].serverAddr, &argv[i][3]);
                break;
            default:
                usage();
                break;
            }
        }
    }
}

/**
 * @brief just main
 *
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char **argv)
{
    signal(SIGINT, ExitGracefully);

    cerr << "\n----------------------------" << endl;
    cerr << "Configuration" << endl;

    // initialize the connections
    initConnections();
    memset(&mNearestObject, 0, sizeof(RDB_OBJECT_STATE_t));
    memset(&mOwnObject, 0, sizeof(RDB_OBJECT_STATE_t));

    /*********************
     * VTD initialization *
     *********************/
    vtdIP = VTD_IP;
    auto tmpVtdIP = getenv("VTD_IP");
    if (nullptr != tmpVtdIP)
    {
        vtdIP = tmpVtdIP;
    }
    // cerr << "vtdIP " << vtdIP << endl;

    vtd_SCP_SocketFD = connectTCP(vtdIP, sConnection[2].port, "VtdScpPort");
    thread t3(recvVtdData, vtd_SCP_SocketFD, vtdIP, SCP_PORT); // keep clearing recv buffer in case of block

    /*********************
     * ROS initialization *
     *********************/
    ros::init(argc, argv, "rosToVtd");
    ros::NodeHandle n;
    ros::Subscriber sub_amr_control = n.subscribe(TOPIC_VEHICLE_CONTROL, 1000, controlCallback);
    n.getParam("enableCarsim", enableCarsim);

    vtdRdbSocketFD = connectTCP(vtdIP, VTD_RDB_PORT, "VtdRdbPort");
    thread t4(recvVtdData, vtdRdbSocketFD, vtdIP, VTD_RDB_PORT); // keep clearing recv buffer in case of block
    t4.detach();

    if (enableCarsim)
    {

        /*********************
         * VTD initialization *
         *********************/
        vtdOdrSocketFD = connectTCP(vtdIP, VTD_ODR_PORT, "VtdOdrPort");

        /************************************
         * Receive RDB_ROAD_QUERY_t from VTD *
         ************************************/
        thread t5(recvVtdData, vtdOdrSocketFD, vtdIP, VTD_ODR_PORT);
        t5.detach();

        /************************
         * Carsim initialization *
         ************************/
        carsimSocketFD = connectTCP(CARSIM_IP, CARSIM_PORT, "CarsimPort");
    }

    cerr << "Configuration completed" << endl;
    cerr << "----------------------------" << endl;

    ros::spin();

    ros::shutdown();
    return 0;
}