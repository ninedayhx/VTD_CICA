#include "ros/ros.h"
#include "std_msgs/Header.h"
#include "common_msgs/Lane.h"
#include "common_msgs/Lanes.h"
#include "common_msgs/Perceptionobjects.h"
#include "common_msgs/Perceptionobject.h"
#include "common_msgs/CICV_Location.h"
#include "RDBHandler.hh"

#include <iostream>
#include <string.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <vector>
#include <set>
#include <signal.h>
#include <ostream>
#include <thread>
#include <mutex>
#include <exception>
#include <yaml-cpp/yaml.h>
#define VERSION "20221101"
#define VTD_IP "127.0.0.1"
#define VTD_DEFAULT_PORT 48190
#define DEFAULT_BUFFER 204800
#define ROS_RATE 50
#define skipFrame 5 // 2022.11.11 frequency of SCP is 1s

#define TOPIC_LANE_DETECTION "/LaneDetection"
#define TOPIC_PERCEPTION_OBJECTS "/tpperception"
#define TOPIC_CICV_LOCATION "/cicv_location"

using std::cerr;
using std::cout;
using std::endl;
using std::exception;
using std::mutex;
using std::ostringstream;
using std::set;
using std::string;
using std::thread;
using std::to_string;
using std::vector;

enum PortType
{
    DEFAULT_PORT,
    SENSOR_PORT
};

common_msgs::Lanes lanes_msg;
common_msgs::Perceptionobjects perception_objects_msg;
common_msgs::Perceptionobjects lidar_objects_msg;
common_msgs::CICV_Location cicv_location_msg;
set<int> laneIDs;
set<int> objectIDs;
mutex lane_lock;
mutex object_lock;
ros::Publisher pub_lanes;
ros::Publisher pub_perception_object;
ros::Publisher pub_cicv_location;
ros::Publisher pub_route_plan;
float object_state_heading;
double x_base;
double y_base;
// 2023.5.23
double x_offset;
double y_offset;
// 2023.5.18
double object_abs_heading;

template <typename T>

void operator>>(const YAML::Node &node, T &config)
{
    config = node.as<T>();
}
static YAML::Node node;

// 计算world坐标系下的位置坐标
void computeCoordinateWorld(const double &x1, const double &y1, const double &x2, const double &y2, const double &alpha, float &xg, float &yg);
// 计算world坐标系下的速度
void computeCoordinateWorldSpeed(const double &x1, const double &y1, const double &x2, const double &y2, const double &alpha, float &v_xg, float &v_yg);

void publishAllMsgs()
{
    // publish lane msg
    lanes_msg.header.frame_id = "base_link";
    lanes_msg.header.stamp = ros::Time::now();
    lanes_msg.num = static_cast<int>(lanes_msg.lanes.size());
    pub_lanes.publish(lanes_msg);

    // publish perception object msg
    perception_objects_msg.header.frame_id = "base_link";
    perception_objects_msg.header.stamp = ros::Time::now();
    perception_objects_msg.num = static_cast<int>(perception_objects_msg.Perceptionobjects.size());
    pub_perception_object.publish(perception_objects_msg);

    cicv_location_msg.header.frame_id = "";
    cicv_location_msg.header.stamp = ros::Time::now();
    pub_cicv_location.publish(cicv_location_msg);

    // cleaning up 防止这些变量占用过多内存，提高程序运行效率。
    lanes_msg.lanes.clear();
    laneIDs.clear();
    perception_objects_msg.Perceptionobjects.clear();
    objectIDs.clear();
}

/**
 * @brief record detected objects and ego info
 *
 * @param simTime
 * @param simFrame
 * @param item
 * @param isExtended
 * @param portType determines the "item" source (either from SENSOR_PORT:6200x or from DEFAULT_PORT:48190)
 */
void handleRDBitem(const double &simTime, const unsigned int &simFrame, RDB_OBJECT_STATE_t &item, bool isExtended, PortType portType)
{

    int playerID = item.base.id;
    int typeID = item.base.type;
    if (portType == SENSOR_PORT && playerID != 1 && (typeID == RDB_OBJECT_TYPE_PLAYER_CAR || typeID == RDB_OBJECT_TYPE_OTHER || typeID == RDB_OBJECT_TYPE_PLAYER_PEDESTRIAN || typeID == RDB_OBJECT_TYPE_BARRIER || typeID == RDB_OBJECT_TYPE_PLAYER_MOTORBIKE))
    {

        common_msgs::Perceptionobject perception_object;
        perception_object.SimTim = double(simTime);
        perception_object.ID = item.base.id;

        // 在FLU坐标系下的位置和速度坐标
        perception_object.x = (float)item.base.pos.x;
        perception_object.y = (float)item.base.pos.y;
        perception_object.v_x = (float)item.ext.speed.x;
        perception_object.v_y = (float)item.ext.speed.y;
        perception_object.a_x = (float)item.ext.accel.x;
        perception_object.a_y = (float)item.ext.accel.y;
        perception_object.heading = (float)item.base.pos.h + object_state_heading;

        object_abs_heading = perception_object.heading;
        if (perception_object.heading > 2 * M_PI)
        {
            perception_object.heading -= 2 * M_PI;
        }
        else if (perception_object.heading < -2 * M_PI)
        {
            perception_object.heading += 4 * M_PI;
        }
        else if (perception_object.heading < 0)
        {
            perception_object.heading += 2 * M_PI;
        }
        perception_object.length = item.base.geo.dimX;
        perception_object.width = item.base.geo.dimY;
        perception_object.height = item.base.geo.dimZ;
        if (item.base.type == 1)
        {
            perception_object.type = 1; // car
        }
        else if (item.base.type == 2)
        {
            perception_object.type = 2; // truck
        }
        else if (item.base.type == 5)
        {
            perception_object.type = 3; // pedestrian
        }
        else if (item.base.type == 13)
        {
            perception_object.type = 4; // motocycle
        }
        else if (item.base.type == 4)
        {
            perception_object.type = 5; // bike
        }
        else
        {
            perception_object.type = 0; // else
        }

        // 在World坐标系下的位置和速度坐标
        float xg, yg, v_xg, v_yg;

        // 在World坐标系下的位置
        computeCoordinateWorld((double)cicv_location_msg.Position_x, (double)cicv_location_msg.Position_y,
                               (double)item.base.pos.x, (double)item.base.pos.y,
                               (double)cicv_location_msg.Yaw, xg, yg);
        // 在World坐标系下的速度
        computeCoordinateWorldSpeed((double)cicv_location_msg.Velocity_x, (double)cicv_location_msg.Velocity_y,
                                    (double)item.ext.speed.x, (double)item.ext.speed.y,
                                    (double)cicv_location_msg.Yaw, v_xg, v_yg);
        perception_object.xg = xg;
        perception_object.yg = yg;
        cout << "xg: " << xg << "  yg: " << yg << endl;
        perception_object.v_xg = v_xg;
        perception_object.v_yg = v_yg;

        // 在World坐标系下，目标物和本车的相对位置和相对速度
        perception_object.xrel = (float)(xg - cicv_location_msg.Position_x);
        perception_object.yrel = (float)(yg - cicv_location_msg.Position_y);
        perception_object.v_xrel = (float)(v_xg - cicv_location_msg.Velocity_x);
        perception_object.v_yrel = (float)(v_yg - cicv_location_msg.Velocity_y);

        perception_objects_msg.Perceptionobjects.push_back(perception_object);
        object_lock.unlock();
    }
    else if (portType == DEFAULT_PORT && playerID == 1)
    { // ego case
        // 给本车cicv_location_msg话题赋值48190
        cicv_location_msg.SimTim = double(simTime);
        cicv_location_msg.Velocity_x = (float)item.ext.speed.x;
        cicv_location_msg.Velocity_y = (float)item.ext.speed.y;
        cicv_location_msg.Accel_x = (float)item.ext.accel.x;
        cicv_location_msg.Accel_y = (float)item.ext.accel.y;
        cicv_location_msg.Position_x = (float)(item.base.pos.x);
        cicv_location_msg.Position_y = (float)(item.base.pos.y);

        cicv_location_msg.Yaw = (float)item.base.pos.h;
        cicv_location_msg.Pitch = (float)item.base.pos.p;
        cicv_location_msg.Roll = (float)item.base.pos.r;
        object_state_heading = cicv_location_msg.Yaw;

        if (cicv_location_msg.Yaw < 0)
        {
            cicv_location_msg.Yaw += 2 * M_PI;
        }
        cicv_location_msg.Angular_velocity_z = (float)item.ext.speed.h;
    }
}

/**
 * @brief record roadmark info which has the source type SENSOR_PORT
 *
 * @param simTime
 * @param SimFrame
 * @param item
 * @param portType determines the "item" source (either from SENSOR_PORT:6200x or from DEFAULT_PORT:48190)
 */
void handleRDBitem(const double &simTime, const unsigned int &SimFrame, RDB_ROADMARK_t &item, PortType portType)
{
    if (portType == SENSOR_PORT)
    {
        int playerID = item.playerId;

        int laneID = (int)item.id;
        // Nation competetion  Lane_Msg
        if (playerID == 1 && laneID <= 6 && laneID % 2 == 0)
        {
            lane_lock.lock();
            common_msgs::Lane lane_msg;
            if (laneIDs.find(laneID) == laneIDs.end())
            {
                laneIDs.insert(laneID);
            }
            else
            {
                lane_lock.unlock();
                return;
            }

            if (laneID == 0)
                lane_msg.lane_idx = 1;
            else if (laneID == 2)
                lane_msg.lane_idx = 2;
            else if (laneID == 4)
                lane_msg.lane_idx = 0;
            else if (laneID == 6)
                lane_msg.lane_idx = 3;
            else
                lane_msg.lane_idx = 122; // why 122?

            lane_msg.c_0 = item.lateralDist;
            lane_msg.c_1 = item.yawRel;
            lane_msg.c_2 = item.curvHor / 2;
            lane_msg.c_3 = item.curvHorDot / 6;

            lanes_msg.lanes.push_back(lane_msg);
            lane_lock.unlock();
        }
    }
}

/**
 * @brief keep parsing rdb msg entry
 *
 * @param simTime
 * @param simFrame
 * @param entryHdr
 * @param portType determines the "item" source (either from SENSOR_PORT:6200x or from DEFAULT_PORT:48190)
 */
void parseRDBMessageEntry(const double &simTime, const unsigned int &simFrame, RDB_MSG_ENTRY_HDR_t *entryHdr, PortType portType)
{

    if (!entryHdr)
        return;

    int noElements = entryHdr->elementSize ? (entryHdr->dataSize / entryHdr->elementSize) : 0;

    if (!noElements)
    { // some elements require special treatment
        switch (entryHdr->pkgId)
        {

        case RDB_PKG_ID_START_OF_FRAME:
            // fprintf( stderr, "void parseRDBMessageEntry: got start of frame\n" );
            break;

        case RDB_PKG_ID_END_OF_FRAME:
            // fprintf( stderr, "void parseRDBMessageEntry: got end of frame\n" );
            break;

        default:
            return;
        }
        return;
    }

    char *dataPtr = (char *)entryHdr;
    dataPtr += entryHdr->headerSize;

    while (noElements--)
    {
        switch (entryHdr->pkgId)
        {

        case RDB_PKG_ID_ROADMARK: // 7
            handleRDBitem(simTime, simFrame, *((RDB_ROADMARK_t *)dataPtr), portType);
            break;

        case RDB_PKG_ID_OBJECT_STATE: // 9
            handleRDBitem(simTime, simFrame, *((RDB_OBJECT_STATE_t *)dataPtr), entryHdr->flags & RDB_PKG_FLAG_EXTENDED, portType);
            break;

        // case RDB_PKG_ID_VEHICLE_SYSTEMS: // 10
        //     handleRDBitem(simTime, simFrame, *((RDB_VEHICLE_SYSTEMS_t*)dataPtr), portType);
        //     break;

        // case RDB_PKG_ID_DRIVER_CTRL: // 26
        //     handleRDBitem(simTime, simFrame, *((RDB_DRIVER_CTRL_t*)dataPtr), portType);
        //     break;

        // case RDB_PKG_ID_TRAFFIC_LIGHT: // 27
        //     // cout << "entryHdr->elementSize: " << entryHdr->elementSize << endl;
        //     handleRDBitem(simTime, simFrame, *((RDB_TRAFFIC_LIGHT_t*)dataPtr), entryHdr->flags & RDB_PKG_FLAG_EXTENDED, portType);
        //     break;

        // case RDB_PKG_ID_LANE_INFO: // 6
        //     handleRDBitem(simTime, simFrame, *((RDB_LANE_INFO_t*)dataPtr), portType);
        //     break;
        // zhangyu 2022.11.11
        // case RDB_PKG_ID_TRAJECTORY:// 34
        //     if ( simFrame % skipFrame == 0 )
        //         showTrajectory(  ( RDB_TRAJECTORY_t* ) dataPtr );
        //     break;
        default:
            break;
        }

        dataPtr += entryHdr->elementSize;
    }
}

/**
 * @brief keep parsing rdb msg
 *
 * @param msg
 * @param isImage
 * @param portType determines the "item" source (either from SENSOR_PORT:6200x or from DEFAULT_PORT:48190)
 */
void parseRDBMessage(RDB_MSG_t *msg, bool &isImage, PortType portType)
{

    if (!msg)
        return;
    if (!msg->hdr.dataSize)
        return;

    auto *entry = (RDB_MSG_ENTRY_HDR_t *)(((char *)msg) + msg->hdr.headerSize);
    uint32_t remainingBytes = msg->hdr.dataSize;

    while (remainingBytes)
    {
        parseRDBMessageEntry(msg->hdr.simTime, msg->hdr.frameNo, entry, portType);

        isImage |= (entry->pkgId == RDB_PKG_ID_IMAGE);

        remainingBytes -= (entry->headerSize + entry->dataSize);

        if (remainingBytes)
            entry = (RDB_MSG_ENTRY_HDR_t *)((((char *)entry) + entry->headerSize + entry->dataSize));
    }
}

/**
 * @brief make a TCP connection
 *
 * @param targetIP
 * @param targetPort
 * @param targetName
 * @return int
 */
int connectTCP(const string &targetIP, int targetPort, const string &targetName)
{

    struct sockaddr_in server
    {
    };
    struct hostent *host;
    int sClient;
    char szServer[128];

    strcpy(szServer, targetIP.c_str());

    sClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (sClient == -1)
    {
        fprintf(stderr, "socket() failed: %s\n", strerror(errno));
        // return 1;
    }

    int opt = 1;
    setsockopt(sClient, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));

    server.sin_family = AF_INET;
    server.sin_port = htons(targetPort);
    server.sin_addr.s_addr = inet_addr(szServer);

    /// If the supplied server address wasn't in the form
    /// "aaa.bbb.ccc.ddd" it's a hostname, so try to resolve it
    if (server.sin_addr.s_addr == INADDR_NONE)
    {
        host = gethostbyname(szServer);
        if (nullptr == host)
        {
            fprintf(stderr, "Unable to resolve %s server: %s\n", szServer, targetName.c_str());
            return 1;
        }
        memcpy(&server.sin_addr, host->h_addr_list[0], host->h_length);
    }
    /// wait for connection
    bool bConnected = false;
    while (ros::ok() && !bConnected)
    {
        if (connect(sClient, (struct sockaddr *)&server, sizeof(server)) == -1)
        {
            fprintf(stderr, "%s connect() failed: %s\n", strerror(errno), targetName.c_str());
            sleep(1);
        }
        else
        {
            bConnected = true;
        }
    }
    cout << targetName << " connected!"
         << " | IP = " << targetIP << " | port = " << targetPort << endl;
    return sClient;
}

/**
 * @brief keep receiving rdb msg from VTD
 *
 * @param vtdRdbSocketFD
 * @param portType determines the "item" source (either from SENSOR_PORT:6200x or from DEFAULT_PORT:48190)
 */
void recvVtdData(int vtdRdbSocketFD, PortType portType, string targetIP, int targetPort)
{

    // cerr << " ----------------------------- portType: " << portType << endl;

    char szBuffer[DEFAULT_BUFFER];
    while (true)
    {

        /// receive raw data from vtd
        int ret;
        unsigned int bytesInBuffer = 0;
        size_t bufferSize = sizeof(RDB_MSG_HDR_t);
        auto *pData = (unsigned char *)calloc(1, bufferSize);

        for (;;)
        {
            // cerr << " ----------------------------- portType: " << portType << endl;
            bool bMsgComplete = false;

            double simTime;
            unsigned int frameNo;

            // read a complete message
            while (!bMsgComplete)
            {

                ret = recv(vtdRdbSocketFD, &szBuffer, DEFAULT_BUFFER, 0);
                if (ret <= 0)
                {
                    auto strPort = to_string(targetPort).c_str();
                    fprintf(stderr, "\n%s disconnected, reconnecting...\n\n", strPort);
                    close(vtdRdbSocketFD);
                    vtdRdbSocketFD = connectTCP(targetIP, targetPort, strPort);
                    break;
                }

                // do we have to grow the buffer??
                if ((bytesInBuffer + ret) > bufferSize)
                {
                    pData = (unsigned char *)realloc(pData, bytesInBuffer + ret);
                    bufferSize = bytesInBuffer + ret;
                }

                memcpy(pData + bytesInBuffer, &szBuffer, ret);
                bytesInBuffer += ret;

                // already complete messagae?
                if (bytesInBuffer >= sizeof(RDB_MSG_HDR_t))
                {
                    auto *hdr = (RDB_MSG_HDR_t *)pData;

                    simTime = hdr->simTime;
                    frameNo = hdr->frameNo;

                    // is this message containing the valid magic number?
                    if (hdr->magicNo != RDB_MAGIC_NO)
                    {
                        fprintf(stderr, "message receiving is out of sync; discarding data");
                        bytesInBuffer = 0;
                    }

                    while (bytesInBuffer >= (hdr->headerSize + hdr->dataSize))
                    {
                        unsigned int msgSize = hdr->headerSize + hdr->dataSize;
                        bool isImage = false;

                        // now parse the message
                        parseRDBMessage((RDB_MSG_t *)pData, isImage, portType);

                        // remove message from queue
                        memmove(pData, pData + msgSize, bytesInBuffer - msgSize);
                        bytesInBuffer -= msgSize;

                        bMsgComplete = true;
                    }
                }
            }

            if (48190 == targetPort)
            {
                publishAllMsgs();
                ROS_INFO("v%s, Topics Published, %d, %f", VERSION, frameNo, simTime);
            }
        }
    }
}

/**
 * @brief gracefully exit the program, elegance never goes out of fashion.
 *
 * @param sig
 */
void ExitGracefully(int sig)
{
    ROS_INFO("VtdToRos Terminated");
    ros::shutdown();
    exit(sig);
}

void SignalHandler(int signal)
{
    ROS_INFO("Received Signal: ", signal);
    ROS_INFO("Received Signal: ", (int)signal);
    exit(signal);
}

/**
 * @brief it's the MAIN, you know?
 *
 * @param argc
 * @param argv
 * @return int
 */
int main(int argc, char **argv)
{

    signal(SIGINT, ExitGracefully);
    signal(SIGSEGV, SignalHandler);

    cerr << "\n----------------------------" << endl;
    cerr << "Configuration" << endl;

    /*********************
     * ROS initialization *
     *********************/

    ros::init(argc, argv, "vtdToRos");
    ros::NodeHandle n;
    ros::Rate loop_rate(ROS_RATE);

    pub_lanes = n.advertise<common_msgs::Lanes>(TOPIC_LANE_DETECTION, 1000);
    pub_perception_object = n.advertise<common_msgs::Perceptionobjects>(TOPIC_PERCEPTION_OBJECTS, 1000);
    pub_cicv_location = n.advertise<common_msgs::CICV_Location>(TOPIC_CICV_LOCATION, 1000);

    // read sensor port num from launch file
    int sensorNum = 0;
    n.getParam("sensorNum", sensorNum);

    vector<string> sensorPortNames(sensorNum); // contains all sensors' name in launch file
    vector<int> sensorPorts(sensorNum);        // contains all sensors' port in launch file
    for (int i = 0; i < sensorNum; ++i)
    {
        ostringstream oss;
        oss << "sensorPort_" << i + 1;
        sensorPortNames[i] = oss.str();
        n.getParam(sensorPortNames[i], sensorPorts[i]);
        // cout << sensorPortNames[i] << ", " << sensorPorts[i] << endl; 2023.5.9注释
    }

    /*********************
     * VTD initialization *
     *********************/

    string vtdIP = VTD_IP;
    auto tmpVtdIP = getenv("VTD_IP");
    if (nullptr != tmpVtdIP)
    {
        vtdIP = tmpVtdIP;
    }
    cerr << "vtdIP " << vtdIP << endl;

    cerr << "Loading following sensor ports..." << endl;
    for (int i = 0; i < sensorNum; ++i)
    {
        auto vtdSensorSocketFD = connectTCP(vtdIP, sensorPorts[i], sensorPortNames[i]);
        thread t(recvVtdData, vtdSensorSocketFD, SENSOR_PORT, vtdIP, sensorPorts[i]);
        t.detach();
    }

    auto vtdRdbSocketFD = connectTCP(vtdIP, VTD_DEFAULT_PORT, "DefaultPort");
    thread t(recvVtdData, vtdRdbSocketFD, DEFAULT_PORT, vtdIP, VTD_DEFAULT_PORT);

    cerr << "Configuration completed" << endl;
    cerr << "----------------------------" << endl;

    /**********
     * ROS run *
     **********/

    while (ros::ok())
    {
        usleep(100000);
    }

    ros::shutdown();
    return 0;
}

// 输入值：x1-自车绝对位置的x坐标，y1-自车绝对位置的y坐标,x2-目标车相对自车的x坐标，y2-目标车相对自车的y坐标,alpha-自车的航向角信息，
// 返回值：xg-目标车绝对位置的x坐标,yg-目标车绝对位置的y坐标
void computeCoordinateWorld(const double &x1, const double &y1, const double &x2, const double &y2, const double &alpha, float &xg, float &yg)
{
    ;
    double dis, beta, theta;
    beta = atan(y2 / x2);
    if (x2 > 0 && y2 > 0)
    {
        beta = beta;
    }
    else if (x2 < 0)
    {
        beta += M_PI;
    }
    else if (x2 > 0 && y2 < 0)
    {
        beta += 2 * M_PI;
    }
    theta = alpha + beta;
    dis = sqrt(pow(y2, 2) + pow(x2, 2));
    xg = x1 + dis * cos((float)theta);
    yg = y1 + dis * sin((float)theta);

    cout << "Xg: " << xg << "Yg: " << yg << endl;
}

// 计算目标车在世界坐标系下的绝对速度
void computeCoordinateWorldSpeed(const double &x1, const double &y1, const double &x2, const double &y2, const double &alpha, float &v_xg, float &v_yg)
{
    v_xg = x1 + x2 * cos((float)alpha) - y2 * sin((float)alpha);
    v_yg = y1 + y2 * cos((float)alpha) + x2 * sin((float)alpha);
    cout << "v_xg: " << v_xg << " v_yg: " << v_yg << endl;
}
