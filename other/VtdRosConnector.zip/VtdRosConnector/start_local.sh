#!/bin/bash

gnome-terminal \
    --window -e 'bash -c "source devel/setup.bash && roscore && /bin/bash"'

sleep 1

gnome-terminal \
    --window -e 'bash -c "source devel/setup.bash && roslaunch --wait vtdToRos vtdToRos.launch && /bin/bash"' \
    --tab    -e 'bash -c "source devel/setup.bash && roslaunch --wait rosToVtd rosToVtd.launch && /bin/bash"' \
