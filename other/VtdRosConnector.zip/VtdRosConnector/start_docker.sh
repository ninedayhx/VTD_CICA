#!/bin/bash

source devel/setup.bash

unbuffer roscore > result/roscore_out.txt 2> result/roscore_err.txt &

sleep 1
unbuffer roslaunch --wait rosToVtd rosToVtd.launch > result/rosToVtd_out.txt 2> result/rosToVtd_err.txt &

sleep 1
unbuffer roslaunch --wait vtdToRos vtdToRos.launch > result/vtdToRos_out.txt 2> result/vtdToRos_err.txt &

